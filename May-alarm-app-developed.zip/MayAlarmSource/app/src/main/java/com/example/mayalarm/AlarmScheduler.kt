package com.example.mayalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("alarm", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val hour = prefs.getInt("hour", 5)
        val minute = prefs.getInt("minute", 30)
        val now = Calendar.getInstance()
        val anchorMillis = prefs.getLong("cycleStartDate", -1L)
        if (anchorMillis < 0L) {
            val first = (now.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            prefs.edit().putLong("cycleStartDate", first.timeInMillis).apply()
        }
        val anchor = Calendar.getInstance().apply { timeInMillis = prefs.getLong("cycleStartDate", 0L) }
        val candidate = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        while (true) {
            val day = (candidate.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val count = daysBetween(anchor, day)
            if (count >= 0 && count % 5 != 4) break
            candidate.add(Calendar.DAY_OF_YEAR, 1)
        }
        val intent = PendingIntent.getBroadcast(context, 1, Intent(context, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, candidate.timeInMillis, intent)
        else am.setExact(AlarmManager.RTC_WAKEUP, candidate.timeInMillis, intent)
    }

    private fun daysBetween(start: Calendar, end: Calendar): Int {
        val cursor = (start.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val target = (end.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        var days = 0
        while (cursor.before(target) && days < 20000) { cursor.add(Calendar.DAY_OF_YEAR, 1); days++ }
        return if (cursor == target) days else -1
    }

    fun cancel(context: Context) {
        val pi = PendingIntent.getBroadcast(context, 1, Intent(context, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
}
