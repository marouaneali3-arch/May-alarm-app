package com.example.mayalarm

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var picker: TimePicker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("alarm", MODE_PRIVATE)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        layout.addView(TextView(this).apply { text = "منبه 4 أيام وراحة"; textSize = 25f })
        layout.addView(TextView(this).apply {
            text = "اختر وقت التنبيه. يرن 4 أيام متتالية، ثم يستريح اليوم الخامس، وتتكرر الدورة تلقائيًا."; textSize = 16f
        })
        picker = TimePicker(this).apply {
            setIs24HourView(true)
            hour = prefs.getInt("hour", 5)
            minute = prefs.getInt("minute", 30)
        }
        layout.addView(picker)
        layout.addView(Button(this).apply {
            text = "تفعيل المنبه"
            setOnClickListener { enableAlarm() }
        })
        layout.addView(Button(this).apply {
            text = "إيقاف الرنين الآن"
            setOnClickListener { stopService(Intent(this@MainActivity, AlarmSoundService::class.java).setAction(AlarmSoundService.ACTION_STOP)) }
        })
        layout.addView(Button(this).apply {
            text = "إيقاف جدول المنبه"
            setOnClickListener {
                AlarmScheduler.cancel(this@MainActivity)
                stopService(Intent(this@MainActivity, AlarmSoundService::class.java))
                prefs.edit().putBoolean("enabled", false).remove("cycleStartDate").apply()
                Toast.makeText(this@MainActivity, "تم إيقاف جدول المنبه", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(TextView(this).apply {
            text = "ملاحظة: اسمح بالإشعارات والتنبيهات الدقيقة، واجعل بطارية التطبيق دون قيود في إعدادات OPPO."; textSize = 13f
        })
        setContentView(layout)
    }

    private fun enableAlarm() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            Toast.makeText(this, "اسمح بالإشعارات ثم اضغط تفعيل المنبه مرة أخرى", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                Toast.makeText(this, "اسمح بالتنبيهات الدقيقة ثم ارجع واضغط تفعيل", Toast.LENGTH_LONG).show()
                return
            }
        }
        val prefs = getSharedPreferences("alarm", MODE_PRIVATE)
        prefs.edit().putInt("hour", picker.hour).putInt("minute", picker.minute)
            .putBoolean("enabled", true).remove("cycleStartDate").apply()
        AlarmScheduler.scheduleNext(this)
        Toast.makeText(this, "تم تفعيل دورة 4 أيام تشغيل ويوم راحة", Toast.LENGTH_LONG).show()
    }
}
